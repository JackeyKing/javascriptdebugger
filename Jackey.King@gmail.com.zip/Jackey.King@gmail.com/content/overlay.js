var DebuggerLoader = {
  showdebugger : function() {
	var head = document.getElementsByTagName("head")[0];
	var js = document.createElement("script");
	js.type="text/javascript";
	js.language="javascript";
	js.src = "file://C:/javascriptdebugger/debugger.js";
	head.appendChild(js);
	//js.onload=function(){oDebugger.showdebugger(true)};
  }
};